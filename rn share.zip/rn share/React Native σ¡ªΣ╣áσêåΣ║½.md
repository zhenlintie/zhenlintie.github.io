autoscale: true
slidenumbers: true

# **React Native 介绍**

---

### React Native 简介

针对 iOS、Android，基于 Javascript 和 React 开发移动客户端。

Web 开发的体验，接近 Native 级别的性能。

React Native 的理念就是：
> Learn once, write anywhere

---
[.autoscale:true]

### React Native 解决了哪些问题？

* Native
	* 版本更新不方便
	* 不同端的功能模块分别管理
	* 公司人员配置、开发成本

* Hybrid
	* 交互体验、性能比较差
	* 功能限制
	
* 其他问题？

---

## 对比

---

### Hybrid

![inline](img/hybrid.jpg)

---

#### HTML + CSS + Javascript

* [Framework7](http://www.framework7.cn/)

		AngularJS   React.js   Vue.js   ...


* [Ionic](http://ionicframework.com/)

		SASS   JavaScript MVVM   AngularJS
		
* [Cordova](http://cordova.apache.org/)

* ...

---

#### Cordova App Architecture
![inline](img/cordovaapparchitecture.png)

---

### 统一开发 -> 多端 Native

---

#### [Weex](http://weex.apache.org/)

![inline](img/weexflow.png)

---

#### [Xamarin](https://developer.xamarin.com/)
Xamarin 将 Native 的 iOS 及 Android API 转换为 C# 函式库供使用者使用，开发人员可使用 C# 撰写程序，并呼叫原生平台（iOS, Android）的 API，且透过良好的设计，可以在不同平台共享部份程序代码。开发人员可透过 Xamarin 编译程序，直接将程序编译为 ARM 的执行档，并进行各平台的封装。编译封装完成的 App 由于不经过中间转译，直接编译为原生的二进制执行文件，因此具有好的运作效能。

---

#### [RubyMotion](http://www.rubymotion.com/)

在 iOS 以及 OS X 系统之上，RubyMotion 基于 Objective-C 的运行时库和 Foundation 类实现了 Ruby 语言。 
在 Android 系统之上，RubyMotion 基于 Android Java 运行时库、Dalvik 以及 ART 实现了 Ruby 语言。

RubyMotion 使用基于 LLVM 构建的革命性的、先进的预编译器（AOT Complier）将项目中的 Ruby 代码编译成经过优化的机器代码。

---

## React Native 工作原理

---

![inline](img/RN_working.png)

---

![](img/ReactNative2.png)

---

### 使用 React Native，会遇到哪些问题？

* 真正的 Native 体验，复杂交互、动效、性能
* 代码共享，分别针对不同平台
* 前端开发人员、Native 开发人员
* 功能需要 RN 官方维护、社区支持
* Native 系统升级，兼容问题
* ...

---

### 相关资料

* [React Native 官网](https://facebook.github.io/react-native/)
* [React Native 中文网](http://reactnative.cn/)
* [React Native Express](http://www.reactnativeexpress.com/)
* [React Native 通信机制详解](http://blog.cnbang.net/tech/2698/)
* [React Native 学习指南](https://github.com/reactnativecn/react-native-guide)
* [Awesome React Native](https://github.com/jondot/awesome-react-native)

---

# React Native 的使用
---
# 1.环境搭建
---
# IDE
- atom
- webstorm
- vscode
- sublime

---
# 包管理
- npm
- yarn

---

# 2.RN 和原生的配置
---

# 环境

---
## Node & npm & yarn
```bash, [.highlight: 5,7,8]
// 安装 Homebrew
// $ ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
$ brew update
$ brew doctor
$ export PATH="/usr/local/bin:$PATH"
// npm will be installed with Node
$ brew install node
$ node -v
v6.11.0
```
---
## nvm
```bash, [.highlight: 2,7,8]
$ curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.2/install.sh | bash
$ nvm ls-remote --lts
        v6.10.1   (LTS: Boron)
        v6.10.2   (LTS: Boron)
        v6.10.3   (LTS: Boron)
->      v6.11.0   (Latest LTS: Boron)
$ nvm install 6 --lts 
$ nvm ls
->      v6.11.0
        v8.1.2
        system
```
---
## Watchman 
```
$ brew install watchman
```

---
## React Native CLI
```bash, [.highlight: 3,5]
$ brew install watchman
$ npm install -g react-native-cli
$ react-native init FirstProject
$ cd FirstProject
$ react-native run-ios
```
![right fit](media/react-native-run-ios.png)

---
## create-react-native-app
> The main limitation of a Create React Native App project is that it must be written in pure JavaScript and not have any dependencies which rely on custom native code

```bash, [.highlight: 2,4,5,6,7]
$ npm install -g create-react-native-app
$ create-react-native-app FirstProject
$ cd FirstProject
$ npm start //run with expo viewer
$ npm run ios //run in simulator
$ npm run eject 
//transform project to the 'react-native init' style
```
---
## react-native init && create-react-native-app output diff 1
 
| react-native init | create-react-native-app |
| --- | --- |
| .babelrc | .babelrc |
| .flowconfig | .flowconfig |
| .gitignore | .gitignore |
| .watchmanconfig | .watchmanconfig |
| package.json | package.json |
| yarn.lock | yarn.lock |
| node_modules | node_modules |
| app.json | app.json |

---
## react-native init && create-react-native-app output diff 2
 
| react-native init | create-react-native-app |
| --- | --- |
| .buckconfig |  |
| android (folder) |  |
| ios (folder) |  |
| index.android.js |  |
| index.ios.js |  |
|  | App.js |
| \_\_tests\_\_ |  |
|  | App.test.js |

---
## react-native-git-upgrade

```bash, [.highlight: 3,4]
$ npm install -g react-native-git-upgrade
$ cd FirstProject
$ react-native-git-upgrade
$ react-native-git-upgrade X.Y // 特定的 React Native 版本
```

---
# 插件
### Atom 插件
- Flow: A Static Type Checker for JavaScript
- Nuclide: A collection of features for Atom
- language-babel: Enable language grammar for JS, Flow and React JS, etc.

---
## Nuclide
```bash
$ apm install nuclide
$ apm install tool-bar
```

---

# Flow 安装

```
$ npm install --save-dev babel-cli babel-preset-flow
$ npm i flow-bin@0.45.0 --save-dev
$ brew install flow // 全局
```

---
# Flow 配置

```bash, [.highlight: 1,2,4,5,7,9]
.flowconfig 关键字：
[ignore]
.*/Libraries/react-native/React.js
[include]
[libs]
node_modules/react-native/flow
[options]
emoji=true
[version]
^0.49.1
```

---
# Flow type checker 示例
```javascript
// javascript 示例代码
function foo(x) {
  return x * 10;
}
foo('Hello, world!');


// bash 
$ flow
App.js:6
  6:   return x * 10;
              ^ string. The operand of an arithmetic operation must be a number.

```
---

![fit](media/flow-on-atom.png)


---

# 3.调试/测试

---
## In-App Developer Menu
Command + D / 摇晃手机

![right fit](media/react-native-ios-debugger.png)

---
## Chrome Developer Tools
- 模拟器 In-App Developer Menu 内打开 Remove JS Debugging
- 真机 iOS 设备修改 `RCTWebSocketExecutor.m`，Android 设备 `adb reverse tcp:8081 tcp:8081`
- 访问 localhost:8081/debugger-ui
- 打开开发者工具（⌘⌥J）
- // Debugging with [Stetho](http://facebook.github.io/stetho/) on Android

![fit](media/react-native-debugger.png)

---
## Set breakpoint

```javascript, [.highlight: 4]
export default class FirstProject extends Component {
  render() {
    console.log("debugger");
    debugger;
    return (
      <View style={styles.container}>
        <Text style={styles.welcome}>
          Welcome to React Native!
        </Text>
      </View>
    );
  }
}
```
---
![fit](media/chrome-dev-tools.png)

---
## react-devtools
```bash
$ npm install -g react-devtools
$ react-devtools
```
![fill](media/react-devtools.png)


---
## Show logs
```bash
$ react-native log-ios
$ react-native log-android
$ adb logcat *:S ReactNative:V ReactNativeJS:V
```

---
# 4.简单的用法
---
# 生命周期
**Mounting Cycle**

| 方法 | 描述 |
| --- | --- |
| `constructor(object props)` | 组件类初始化，原生 UI 尚未渲染 |
| `componentWillMount()` | 只会被调起一次，在渲染发生的第一次前，原生 UI 尚未渲染 |
| `render() -> React Element` | 返回 null 或者 React 元素 |
| `componentDidMount()` | 只会被调起一次，在渲染发生的第一次后。在此回调中可以执行异步 API |
 
---
# 生命周期
**Updating Cycle**

| 方法 | 描述 |
| --- | --- |
| `componentWillReceiveProps(object nextProps)` | 组件父级传递了新的 `props`，此组件会重新渲染 |
| `shouldComponentUpdate(object nextProps, object nextState) -> boolean` | 基于新的 `props` 和 `state` 返回是否要重新渲染，默认 `true` |
| `componentWillUpdate(object nextProps, object nextState)` | 决定重新渲染后触发 |
| `render() -> React Element` | 返回 null 或者 React 元素 |
| `componentDidUpdate(object prevProps, object prevState)` | 重新渲染后触发 |

---
# 组件

---
# View
## Usage

```javascript
import { Image, View } from 'react-native';
export default class Test extends Component {
  render() {
    return (
      <View style={{flexDirection: 'row', height: 100, padding: 20}}>
        <View style={{backgroundColor: 'blue', flex: 0.3}} />
        <View style={{backgroundColor: 'red', flex: 0.5}} />
      </View>
    );
  }
}
```
---
# View
## Props

| Props | 描述 |
| --- | --- |
| style?: style | 样式 |
| onLayout?: PropTypes.func | 布局事件 |

---

# Text
## Usage

```javascript
import { Text, View } from 'react-native';
export default class Test extends Component {
  render() {
    return (
        <View>
            <Text>
              Welcome to React Native!
            </Text>
        </View>
    );
  }
}
```
---
# Text
## Props

| Props | 描述 |
| --- | --- |
| style?: style | 样式 |
| numberOfLines?: PropTypes.number | 行数 |
| onLayout?: PropTypes.func | 布局事件 |
| onLongPress?: PropTypes.func  | 长按事件 |
| onPress?: PropTypes.func | 点按事件 |
| selectable?: PropTypes.bool | 可选 |

---
# Image
## Usage

```javascript
import { Image, View } from 'react-native';
export default class Test extends Component {
  render() {
    return (
        <View>
            <Image
              source={require('./img/favicon.png')}
            />
            <Image
              style={{width: 50, height: 50}}
              source={{uri: 'https://facebook.github.io/react/img/logo_og.png'}}
            />
        </View>
    );
  }
}
```
---
# Image
## Props

| Props | 描述 |
| --- | --- |
| style?: style | 样式 |
| onLayout?: PropTypes.func | 布局事件 |
| onLoadStart?: PropTypes.func | 加载开始 |
| onLoad?: PropTypes.func | 加载成功 |
| onError?: PropTypes.func | 加载失败 |
| onLoadEnd?: PropTypes.func | 加载结束（成功或失败） |
| resizeMode?: PropTypes.oneOf(['cover', 'contain', 'stretch', 'repeat', 'center']) | 图片拉伸模式 |
| source?: ImageSourcePropType | 图片源（URL 或者 本地资源） |

---
# TextInput
## Usage

```javascript
import { Image, View } from 'react-native';
export default class Test extends Component {
  render() {
    return (
      <TextInput
        style={{height: 40, borderColor: 'gray', borderWidth: 1}}
        onChangeText={(text) => this.setState({text})}
        value={this.state.text}
      />
    );
  }
}
```
---
# TextInput
## Props

| Props | 描述 |
| --- | --- |
| style?: style | 样式 |
| onLayout?: PropTypes.func | 布局事件 |
| autoCapitalize?: PropTypes.oneOf(['none','sentences','words','characters',]) |  |

---
# 网络

- fetch
- XMLHttpRequest

---
# [fetch](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch)

```javascript
const response = await fetch(uri)
const json = await response.json()
const text = await response.text()
```

---
# 存储

- AsyncStorage
- Redux Persist
- Realm

---
# AsyncStorage
```
await getItem(key) => ?string
await setItem(key, value)
await clear()
await removeItem(key)
await mergeItem(key, value)
await getAllKeys() => ?Array<string>;
await flushGetRequests()
await multiGet(keys) => ?Array<Array<string>>;
await multiSet(keyValuePairs)
await multiRemove(keys)
await multiMerge(keyValuePairs)
```

---
# 动画

- [Animated](https://facebook.github.io/react-native/docs/animated.html#methods)
- [LayoutAnimation](https://facebook.github.io/react-native/docs/animations.html#layoutanimation)

---
# Animated
## 数值
```javascript
Animated.Value()
// type AnimatedValue
Animated.ValueXY()
// type AnimatedValueXY
```
---
# Animated
## 数值动画
```javascript
Animated.decay()
// 减速动画
Animated.spring()
// 物理弹簧动画
Animated.timing() 缓动函数
// 默认 symmetric easeInOut
// See http://easings.net/zh-cn
```

---
# Animated
## 组件动画
```javascript
static createAnimatedComponent(Component)
=>
Animated.Image
Animated.ScrollView
Animated.Text
Animated.View
```

---
# Animated
## 连接动画
```javascript
Animated.delay()
Animated.parallel()
Animated.sequence()
Animated.stagger()
```
---
# Animated
## 组合动画数值
```javascript
Animated.add()
Animated.divide()
Animated.modulo()
Animated.multiply()
```

---
# 5.第三方库
---
 **网络**
https://github.com/mzabriskie/axios
https://github.com/visionmedia/superagent

**动画**
[https://github.com/oblador/react-native-animatable](https://github.com/oblador/react-native-animatable)

**状态**
https://github.com/reactjs/redux

**相机**
[https://github.com/wix/react-native-camera-kit](https://github.com/wix/react-native-camera-kit)
[https://github.com/lwansbrough/react-native-camera](https://github.com/lwansbrough/react-native-camera)

**UI 库**
[https://github.com/shoutem/ui](https://github.com/shoutem/ui)
[https://github.com/react-native-community/react-native-elements](https://github.com/react-native-community/react-native-elements)
[https://github.com/GeekyAnts/NativeBase](https://github.com/GeekyAnts/NativeBase)
[https://github.com/akveo/react-native-ui-kitten](https://github.com/akveo/react-native-ui-kitten)









